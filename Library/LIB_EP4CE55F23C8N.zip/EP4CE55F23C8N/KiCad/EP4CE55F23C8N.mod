PCBNEW-LibModule-V1  2026-06-12 10:36:05
# encoding utf-8
Units mm
$INDEX
BGA484C100P22X22_2300X2300X240
$EndINDEX
$MODULE BGA484C100P22X22_2300X2300X240
Po 0 0 0 15 6a2be115 00000000 ~~
Li BGA484C100P22X22_2300X2300X240
Cd 484-Pin FineLine Ball-Grid Array (FBGA) - Wire Bond - A:2.40
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "BGA484C100P22X22_2300X2300X240"
DS -13.5 -13.5 13.5 -13.5 0.05 24
DS 13.5 -13.5 13.5 13.5 0.05 24
DS 13.5 13.5 -13.5 13.5 0.05 24
DS -13.5 13.5 -13.5 -13.5 0.05 24
DS -11.5 -11.5 11.5 -11.5 0.1 24
DS 11.5 -11.5 11.5 11.5 0.1 24
DS 11.5 11.5 -11.5 11.5 0.1 24
DS -11.5 11.5 -11.5 -11.5 0.1 24
DS -11.5 -5.75 -5.75 -11.5 0.1 24
DS -10.5 -11.5 11.5 -11.5 0.2 21
DS 11.5 -11.5 11.5 11.5 0.2 21
DS 11.5 11.5 -11.5 11.5 0.2 21
DS -11.5 11.5 -11.5 -10.5 0.2 21
DS -11.5 -10.5 -10.5 -11.5 0.2 21
DC -11.5 -11.5 -11.4 -11.5 0.254 21
$PAD
Po -10.5 -10.5
Sh "A1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -10.5
Sh "A2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -10.5
Sh "A3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -10.5
Sh "A4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -10.5
Sh "A5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -10.5
Sh "A6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -10.5
Sh "A7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -10.5
Sh "A8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -10.5
Sh "A9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -10.5
Sh "A10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -10.5
Sh "A11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -10.5
Sh "A12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -10.5
Sh "A13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -10.5
Sh "A14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -10.5
Sh "A15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -10.5
Sh "A16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -10.5
Sh "A17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -10.5
Sh "A18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -10.5
Sh "A19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -10.5
Sh "A20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -10.5
Sh "A21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -10.5
Sh "A22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -9.5
Sh "B1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -9.5
Sh "B2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -9.5
Sh "B3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -9.5
Sh "B4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -9.5
Sh "B5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -9.5
Sh "B6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -9.5
Sh "B7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -9.5
Sh "B8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -9.5
Sh "B9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -9.5
Sh "B10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -9.5
Sh "B11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -9.5
Sh "B12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -9.5
Sh "B13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -9.5
Sh "B14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -9.5
Sh "B15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -9.5
Sh "B16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -9.5
Sh "B17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -9.5
Sh "B18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -9.5
Sh "B19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -9.5
Sh "B20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -9.5
Sh "B21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -9.5
Sh "B22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -8.5
Sh "C1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -8.5
Sh "C2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -8.5
Sh "C3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -8.5
Sh "C4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -8.5
Sh "C5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -8.5
Sh "C6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -8.5
Sh "C7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -8.5
Sh "C8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -8.5
Sh "C9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -8.5
Sh "C10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -8.5
Sh "C11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -8.5
Sh "C12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -8.5
Sh "C13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -8.5
Sh "C14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -8.5
Sh "C15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -8.5
Sh "C16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -8.5
Sh "C17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -8.5
Sh "C18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -8.5
Sh "C19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -8.5
Sh "C20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -8.5
Sh "C21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -8.5
Sh "C22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -7.5
Sh "D1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -7.5
Sh "D2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -7.5
Sh "D3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -7.5
Sh "D4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -7.5
Sh "D5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -7.5
Sh "D6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -7.5
Sh "D7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -7.5
Sh "D8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -7.5
Sh "D9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -7.5
Sh "D10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -7.5
Sh "D11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -7.5
Sh "D12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -7.5
Sh "D13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -7.5
Sh "D14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -7.5
Sh "D15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -7.5
Sh "D16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -7.5
Sh "D17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -7.5
Sh "D18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -7.5
Sh "D19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -7.5
Sh "D20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -7.5
Sh "D21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -7.5
Sh "D22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -6.5
Sh "E1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -6.5
Sh "E2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -6.5
Sh "E3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -6.5
Sh "E4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -6.5
Sh "E5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -6.5
Sh "E6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -6.5
Sh "E7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -6.5
Sh "E8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -6.5
Sh "E9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -6.5
Sh "E10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -6.5
Sh "E11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -6.5
Sh "E12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -6.5
Sh "E13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -6.5
Sh "E14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -6.5
Sh "E15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -6.5
Sh "E16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -6.5
Sh "E17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -6.5
Sh "E18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -6.5
Sh "E19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -6.5
Sh "E20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -6.5
Sh "E21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -6.5
Sh "E22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -5.5
Sh "F1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -5.5
Sh "F2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -5.5
Sh "F3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -5.5
Sh "F4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -5.5
Sh "F5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -5.5
Sh "F6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -5.5
Sh "F7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -5.5
Sh "F8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -5.5
Sh "F9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -5.5
Sh "F10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -5.5
Sh "F11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -5.5
Sh "F12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -5.5
Sh "F13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -5.5
Sh "F14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -5.5
Sh "F15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -5.5
Sh "F16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -5.5
Sh "F17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -5.5
Sh "F18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -5.5
Sh "F19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -5.5
Sh "F20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -5.5
Sh "F21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -5.5
Sh "F22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -4.5
Sh "G1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -4.5
Sh "G2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -4.5
Sh "G3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -4.5
Sh "G4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -4.5
Sh "G5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -4.5
Sh "G6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -4.5
Sh "G7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -4.5
Sh "G8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -4.5
Sh "G9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -4.5
Sh "G10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -4.5
Sh "G11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -4.5
Sh "G12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -4.5
Sh "G13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -4.5
Sh "G14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -4.5
Sh "G15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -4.5
Sh "G16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -4.5
Sh "G17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -4.5
Sh "G18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -4.5
Sh "G19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -4.5
Sh "G20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -4.5
Sh "G21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -4.5
Sh "G22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -3.5
Sh "H1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -3.5
Sh "H2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -3.5
Sh "H3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -3.5
Sh "H4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -3.5
Sh "H5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -3.5
Sh "H6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -3.5
Sh "H7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -3.5
Sh "H8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -3.5
Sh "H9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -3.5
Sh "H10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -3.5
Sh "H11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -3.5
Sh "H12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -3.5
Sh "H13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -3.5
Sh "H14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -3.5
Sh "H15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -3.5
Sh "H16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -3.5
Sh "H17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -3.5
Sh "H18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -3.5
Sh "H19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -3.5
Sh "H20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -3.5
Sh "H21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -3.5
Sh "H22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -2.5
Sh "J1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -2.5
Sh "J2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -2.5
Sh "J3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -2.5
Sh "J4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -2.5
Sh "J5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -2.5
Sh "J6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -2.5
Sh "J7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -2.5
Sh "J8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -2.5
Sh "J9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -2.5
Sh "J10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -2.5
Sh "J11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -2.5
Sh "J12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -2.5
Sh "J13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -2.5
Sh "J14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -2.5
Sh "J15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -2.5
Sh "J16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -2.5
Sh "J17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -2.5
Sh "J18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -2.5
Sh "J19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -2.5
Sh "J20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -2.5
Sh "J21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -2.5
Sh "J22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -1.5
Sh "K1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -1.5
Sh "K2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -1.5
Sh "K3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -1.5
Sh "K4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -1.5
Sh "K5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -1.5
Sh "K6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -1.5
Sh "K7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -1.5
Sh "K8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -1.5
Sh "K9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -1.5
Sh "K10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -1.5
Sh "K11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -1.5
Sh "K12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -1.5
Sh "K13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -1.5
Sh "K14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -1.5
Sh "K15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -1.5
Sh "K16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -1.5
Sh "K17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -1.5
Sh "K18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -1.5
Sh "K19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -1.5
Sh "K20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -1.5
Sh "K21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -1.5
Sh "K22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 -0.5
Sh "L1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 -0.5
Sh "L2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 -0.5
Sh "L3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 -0.5
Sh "L4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 -0.5
Sh "L5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 -0.5
Sh "L6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 -0.5
Sh "L7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 -0.5
Sh "L8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 -0.5
Sh "L9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -0.5
Sh "L10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 -0.5
Sh "L11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 -0.5
Sh "L12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -0.5
Sh "L13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 -0.5
Sh "L14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 -0.5
Sh "L15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 -0.5
Sh "L16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 -0.5
Sh "L17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 -0.5
Sh "L18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 -0.5
Sh "L19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 -0.5
Sh "L20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 -0.5
Sh "L21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 -0.5
Sh "L22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 0.5
Sh "M1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 0.5
Sh "M2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 0.5
Sh "M3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 0.5
Sh "M4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 0.5
Sh "M5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 0.5
Sh "M6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 0.5
Sh "M7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 0.5
Sh "M8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 0.5
Sh "M9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 0.5
Sh "M10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 0.5
Sh "M11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 0.5
Sh "M12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 0.5
Sh "M13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 0.5
Sh "M14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 0.5
Sh "M15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 0.5
Sh "M16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 0.5
Sh "M17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 0.5
Sh "M18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 0.5
Sh "M19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 0.5
Sh "M20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 0.5
Sh "M21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 0.5
Sh "M22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 1.5
Sh "N1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 1.5
Sh "N2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 1.5
Sh "N3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 1.5
Sh "N4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 1.5
Sh "N5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 1.5
Sh "N6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 1.5
Sh "N7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 1.5
Sh "N8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 1.5
Sh "N9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 1.5
Sh "N10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 1.5
Sh "N11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 1.5
Sh "N12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 1.5
Sh "N13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 1.5
Sh "N14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 1.5
Sh "N15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 1.5
Sh "N16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 1.5
Sh "N17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 1.5
Sh "N18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 1.5
Sh "N19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 1.5
Sh "N20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 1.5
Sh "N21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 1.5
Sh "N22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 2.5
Sh "P1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 2.5
Sh "P2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 2.5
Sh "P3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 2.5
Sh "P4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 2.5
Sh "P5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 2.5
Sh "P6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 2.5
Sh "P7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 2.5
Sh "P8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 2.5
Sh "P9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 2.5
Sh "P10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 2.5
Sh "P11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 2.5
Sh "P12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 2.5
Sh "P13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 2.5
Sh "P14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 2.5
Sh "P15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 2.5
Sh "P16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 2.5
Sh "P17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 2.5
Sh "P18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 2.5
Sh "P19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 2.5
Sh "P20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 2.5
Sh "P21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 2.5
Sh "P22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 3.5
Sh "R1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 3.5
Sh "R2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 3.5
Sh "R3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 3.5
Sh "R4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 3.5
Sh "R5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 3.5
Sh "R6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 3.5
Sh "R7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 3.5
Sh "R8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 3.5
Sh "R9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 3.5
Sh "R10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 3.5
Sh "R11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 3.5
Sh "R12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 3.5
Sh "R13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 3.5
Sh "R14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 3.5
Sh "R15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 3.5
Sh "R16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 3.5
Sh "R17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 3.5
Sh "R18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 3.5
Sh "R19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 3.5
Sh "R20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 3.5
Sh "R21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 3.5
Sh "R22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 4.5
Sh "T1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 4.5
Sh "T2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 4.5
Sh "T3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 4.5
Sh "T4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 4.5
Sh "T5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 4.5
Sh "T6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 4.5
Sh "T7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 4.5
Sh "T8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 4.5
Sh "T9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 4.5
Sh "T10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 4.5
Sh "T11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 4.5
Sh "T12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 4.5
Sh "T13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 4.5
Sh "T14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 4.5
Sh "T15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 4.5
Sh "T16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 4.5
Sh "T17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 4.5
Sh "T18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 4.5
Sh "T19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 4.5
Sh "T20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 4.5
Sh "T21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 4.5
Sh "T22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 5.5
Sh "U1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 5.5
Sh "U2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 5.5
Sh "U3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 5.5
Sh "U4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 5.5
Sh "U5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 5.5
Sh "U6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 5.5
Sh "U7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 5.5
Sh "U8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 5.5
Sh "U9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 5.5
Sh "U10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 5.5
Sh "U11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 5.5
Sh "U12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 5.5
Sh "U13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 5.5
Sh "U14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 5.5
Sh "U15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 5.5
Sh "U16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 5.5
Sh "U17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 5.5
Sh "U18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 5.5
Sh "U19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 5.5
Sh "U20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 5.5
Sh "U21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 5.5
Sh "U22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 6.5
Sh "V1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 6.5
Sh "V2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 6.5
Sh "V3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 6.5
Sh "V4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 6.5
Sh "V5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 6.5
Sh "V6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 6.5
Sh "V7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 6.5
Sh "V8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 6.5
Sh "V9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 6.5
Sh "V10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 6.5
Sh "V11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 6.5
Sh "V12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 6.5
Sh "V13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 6.5
Sh "V14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 6.5
Sh "V15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 6.5
Sh "V16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 6.5
Sh "V17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 6.5
Sh "V18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 6.5
Sh "V19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 6.5
Sh "V20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 6.5
Sh "V21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 6.5
Sh "V22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 7.5
Sh "W1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 7.5
Sh "W2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 7.5
Sh "W3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 7.5
Sh "W4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 7.5
Sh "W5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 7.5
Sh "W6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 7.5
Sh "W7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 7.5
Sh "W8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 7.5
Sh "W9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 7.5
Sh "W10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 7.5
Sh "W11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 7.5
Sh "W12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 7.5
Sh "W13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 7.5
Sh "W14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 7.5
Sh "W15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 7.5
Sh "W16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 7.5
Sh "W17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 7.5
Sh "W18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 7.5
Sh "W19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 7.5
Sh "W20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 7.5
Sh "W21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 7.5
Sh "W22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 8.5
Sh "Y1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 8.5
Sh "Y2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 8.5
Sh "Y3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 8.5
Sh "Y4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 8.5
Sh "Y5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 8.5
Sh "Y6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 8.5
Sh "Y7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 8.5
Sh "Y8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 8.5
Sh "Y9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 8.5
Sh "Y10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 8.5
Sh "Y11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 8.5
Sh "Y12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 8.5
Sh "Y13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 8.5
Sh "Y14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 8.5
Sh "Y15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 8.5
Sh "Y16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 8.5
Sh "Y17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 8.5
Sh "Y18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 8.5
Sh "Y19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 8.5
Sh "Y20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 8.5
Sh "Y21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 8.5
Sh "Y22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 9.5
Sh "AA1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 9.5
Sh "AA2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 9.5
Sh "AA3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 9.5
Sh "AA4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 9.5
Sh "AA5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 9.5
Sh "AA6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 9.5
Sh "AA7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 9.5
Sh "AA8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 9.5
Sh "AA9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 9.5
Sh "AA10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 9.5
Sh "AA11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 9.5
Sh "AA12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 9.5
Sh "AA13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 9.5
Sh "AA14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 9.5
Sh "AA15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 9.5
Sh "AA16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 9.5
Sh "AA17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 9.5
Sh "AA18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 9.5
Sh "AA19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 9.5
Sh "AA20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 9.5
Sh "AA21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 9.5
Sh "AA22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -10.5 10.5
Sh "AB1" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -9.5 10.5
Sh "AB2" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -8.5 10.5
Sh "AB3" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -7.5 10.5
Sh "AB4" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -6.5 10.5
Sh "AB5" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -5.5 10.5
Sh "AB6" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -4.5 10.5
Sh "AB7" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -3.5 10.5
Sh "AB8" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -2.5 10.5
Sh "AB9" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 10.5
Sh "AB10" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.5 10.5
Sh "AB11" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.5 10.5
Sh "AB12" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 10.5
Sh "AB13" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 2.5 10.5
Sh "AB14" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 3.5 10.5
Sh "AB15" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 4.5 10.5
Sh "AB16" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 5.5 10.5
Sh "AB17" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 6.5 10.5
Sh "AB18" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 7.5 10.5
Sh "AB19" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 8.5 10.5
Sh "AB20" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 9.5 10.5
Sh "AB21" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 10.5 10.5
Sh "AB22" C 0.5 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE BGA484C100P22X22_2300X2300X240
$EndLIBRARY
